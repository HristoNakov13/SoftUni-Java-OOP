package barracksReturnOfTheDependancies.contracts;

public interface Executable {

	String execute();

}
