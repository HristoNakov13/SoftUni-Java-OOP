package barracksReturnOfTheDependancies.contracts;

public interface Unit extends Destroyable, Attacker {
}
