package barracksReturnOfTheDependancies.contracts;

public interface UnitFactory {

    Unit createUnit(String unitType);
}