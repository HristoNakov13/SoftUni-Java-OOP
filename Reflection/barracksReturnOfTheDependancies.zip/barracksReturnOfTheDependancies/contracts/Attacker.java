package barracksReturnOfTheDependancies.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
