package barracksReturnOfTheDependancies.contracts;

public interface Runnable {
	void run();
}
