package barracksExtended.contracts;

public interface Runnable {
	void run();
}
