package barracksExtended.contracts;

public interface Executable {

	String execute();

}
