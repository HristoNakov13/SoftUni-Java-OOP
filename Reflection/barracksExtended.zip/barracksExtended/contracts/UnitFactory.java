package barracksExtended.contracts;

public interface UnitFactory {

    Unit createUnit(String unitType);
}