package barracksExtended.contracts;

public interface Unit extends Destroyable, Attacker {
}
