package barracksExtended.contracts;

public interface Attacker {
    
    int getAttackDamage();
}
